package com.ddm.photolike2.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

public class FeedPostView extends View {
    public FeedPostView(Context context) {
        super(context);
    }

    public FeedPostView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}
